#!/bin/bash
set -e
sudo apt-get install autotools-dev automake -y
./bootstrap
./configure CC=kcc CFLAGS=-fissue-report=report.json
make
rv-html-report report.json -o report
rv-upload-report `pwd`/report
