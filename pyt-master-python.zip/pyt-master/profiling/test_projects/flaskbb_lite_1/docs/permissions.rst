.. _permissions:

Permission (WIP)
================

a moderator is allowed to do the following things:

    enter the management panel
    process reports
    edit user (if he has the permission)
    ban users (if he has the permission)
