:orphan:

Welcome to FlaskBB
==================

FlaskBB is a lightweight forum software in Flask.


Links
-----

`documentation <http://flaskbb.readthedocs.org/en/latest/index.html/>`_
| `source <http://github.com/sh4nks/flaskbb>`_


.. include:: contents.rst.inc
