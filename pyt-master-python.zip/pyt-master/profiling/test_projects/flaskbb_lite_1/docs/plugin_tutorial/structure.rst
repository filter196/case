.. _structure:

Step 1: Structure
=================
