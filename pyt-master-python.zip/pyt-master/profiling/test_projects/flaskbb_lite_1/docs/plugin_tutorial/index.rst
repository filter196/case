.. _tutorial:

Plugin Tutorial (WIP)
=====================


This tutorial is based on the plugin which is shipped by default with FlaskBB.
If you want the full sourcecode in advance or for comparison, check out
the `portal plugin`_.

.. _portal plugin:
   https://github.com/sh4nks/flaskbb/tree/master/flaskbb/plugins/portal

.. toctree::
   :maxdepth: 2

   structure
