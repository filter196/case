class Test():
    def __init__(self, a):
        self.a = a
    def foo(self):
        pass

t = Test()
t.foo()
