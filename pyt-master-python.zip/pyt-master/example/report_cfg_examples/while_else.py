x = 0
while x < 5:
    print(x)
    x += 1
else:
    print('h')
