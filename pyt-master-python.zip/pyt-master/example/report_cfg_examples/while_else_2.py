while x < 100:
    x += 1
    x += 2
else:
    x += 3
    x += 4
