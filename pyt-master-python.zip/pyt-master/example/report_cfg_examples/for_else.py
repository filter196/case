for x in range(5):
    if invalid_value(x):
        break
    print(x)
else:
    print('Accepted')
