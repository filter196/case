from A import B
import A as foo
b = B('str')
c = foo.B('sss')
