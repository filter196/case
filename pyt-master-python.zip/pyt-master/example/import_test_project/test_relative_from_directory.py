# Must be run as module via -m
from .foo import bar


bar.H('hey')
