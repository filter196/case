from package_with_function import StarbucksVisitor


StarbucksVisitor()
