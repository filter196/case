from package_with_file import Starbucks


Starbucks.Tea()
