from package_with_file_and_alias import Eataly


Eataly.Tea()
