def al():
    print ("B")
