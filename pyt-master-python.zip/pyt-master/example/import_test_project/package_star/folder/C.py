def pastor():
    print ("C")
