def fast():
    print ("real fast")
