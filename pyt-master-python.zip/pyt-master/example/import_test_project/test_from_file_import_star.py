from A import *


B("60")
C("minute")
D("IPA")
