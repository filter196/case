def foo(s):
    return s + "see"
