def foo(s):
    return s + "bee"
