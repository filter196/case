def cosme(s):
    return s + "aaa"
