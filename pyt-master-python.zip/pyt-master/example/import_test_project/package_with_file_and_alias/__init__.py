from .nested_folder_without_init import Starbucks as Eataly
