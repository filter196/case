import package_with_folder

package_with_folder.nested_folder_with_init.moose.fast()
