from ..foo.bar import H

result = H('hey')
