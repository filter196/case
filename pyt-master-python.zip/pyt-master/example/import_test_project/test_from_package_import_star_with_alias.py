from package_star_with_alias import *


husk.cobia()
meringue.al()
corn.mousse.pastor()
