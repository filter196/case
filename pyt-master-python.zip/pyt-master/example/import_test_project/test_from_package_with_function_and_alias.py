from package_with_function_and_alias import EatalyVisitor


EatalyVisitor()
