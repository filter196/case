from .A import B as keens, C, D as duck_house


a = keens('mutton')
b = C('tasting')
c = duck_house('peking')
