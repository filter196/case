def B(s):
    return s

def C(s):
    return s + "see"

def D(s):
    return s + "dee"
