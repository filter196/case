from import_os import foo as f
from import_ast import bar as b
from import_math import num as n
