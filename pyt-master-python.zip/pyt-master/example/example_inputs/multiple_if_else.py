if True:
    x = 0
else:
    y = 0
if True:
    z = 0
if False:
    k = 0
