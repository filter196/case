def foo(a, b, c, x):
    print(a)
    print(b)
    return c

y = 0
x = foo(1, 0, 2, 3)
z = 0
