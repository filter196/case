# import random

def foo():
    print('h')

def bar(x):
    y = input()
    print(y)
    print(x)

def baz(x):
    x = 1
    return x+1

y = input()
foo()
#bar(3)
#x = baz(1)
#print(y)
