def foo(en):
    return en

x = 5
request.args.get('param', 'not set')
y = foo(x)
c = 6
