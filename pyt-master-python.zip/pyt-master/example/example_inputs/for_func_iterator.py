def foo():
    return range(1, 8)

for x in foo():
    print(x)    
