while x > 0:
    x += 1
    x += 2
else:
    x += 3
    x += 4
x += 5
