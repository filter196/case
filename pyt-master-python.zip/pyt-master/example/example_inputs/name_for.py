for x in l:
    print(x)
