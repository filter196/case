def bar(x):
    y = input()
    print(y)
    print(x)

y = input()
bar(y)
