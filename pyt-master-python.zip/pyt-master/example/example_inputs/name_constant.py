x = True
if True:
    y = 0
else:
    y = 1
