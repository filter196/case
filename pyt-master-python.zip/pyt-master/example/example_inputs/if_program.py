x = input()
if x > 0:
    y = x + 1
print(x)
