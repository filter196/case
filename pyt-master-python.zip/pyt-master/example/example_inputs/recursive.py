def rec(x):
    if x > 0:
        wat = x-1
        rec(wat)

print('This is fun')
rec(10)
