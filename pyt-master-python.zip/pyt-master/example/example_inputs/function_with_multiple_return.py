def foo():
    a = 1
    if a == 1:
        return 0
    return a

foo()
