while x != 10:
    if x > 0:
        print(x)
        break
    else:
        print('hest')
print('next')
