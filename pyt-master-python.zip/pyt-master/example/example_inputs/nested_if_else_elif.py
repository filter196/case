if True:
    y = 0
    if False:
        x = 1
    elif True:
        x = 2
    else:
        x = 3
elif False:
    y = 1
else:
    y = 2
