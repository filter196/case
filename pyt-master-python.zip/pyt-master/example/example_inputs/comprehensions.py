l = [x for x in [1,2,3]]
ll = [(x, y) for x in [1,2,3] for y in [4,5,6]]
d = {i : x for i,x in enumerate([1,2,3])}
s = {x for x in [1,2,3,2,2,1,2]}
g = (x for x in [1,2,3])
dd = { x + y : y for x in [1,2,3] for y in [4,5,6]} 
