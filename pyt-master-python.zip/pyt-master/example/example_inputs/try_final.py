try:
    value = None
except ImportError:
    value = 1
finally:
    print('goodbye')
