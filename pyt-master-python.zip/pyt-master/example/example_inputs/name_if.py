x = 1
if x:
    y = 1
