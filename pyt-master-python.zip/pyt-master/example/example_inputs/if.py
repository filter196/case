if True:
    x = 0
