if not x > 0:
    pass
