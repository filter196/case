y = 1
for x in range(5):
    g = 10
    if x > y:
        while y < 5:
            print( x)
            x += 1
        else:
            print(y + x)
    else:
        print(x*2)
        h = g * 2

print(x)
