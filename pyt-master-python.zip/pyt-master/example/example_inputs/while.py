x = int(input())
while x < 10:
    x = x + 1
    if x == 5:
        break
else:
    x = 6
print(x)
