﻿#region Using directives

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Security.Permissions;
using System;
using System.Security;

#endregion

[assembly: AssemblyTitle("BlogEngine.NET")]
[assembly: AssemblyDescription("BlogEngine.NET")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BlogEngine.NET")]
[assembly: AssemblyCopyright("Copyright @ 2007-2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
[assembly: AllowPartiallyTrustedCallers]
[assembly: PermissionSet(SecurityAction.RequestMinimum, Name = "Nothing")]

[assembly: AssemblyVersion("1.6.0.0")]