
# for test "i"

import sys

def foo():
	a = 2
	return

i = 0
if i>1:
	a = 3
	sys.exit()

print "done"	
