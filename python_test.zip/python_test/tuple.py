
a = 1,2,3
b = (1,2,3)
c = 1
d = 1
e = (1)
f = (1,)

print type(a), type(b)
print type(c), type(d)
print type(e), type(f)
