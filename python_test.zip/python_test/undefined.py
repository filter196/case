
import os

a += 1
b = 1
b += 1
d = c
os.test1
sys.test2
