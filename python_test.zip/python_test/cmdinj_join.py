home = os.getenv('APPHOME')
cmd = home.join(INITCMD)
os.system(cmd);
