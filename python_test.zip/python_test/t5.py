a   =   [[0   for   a   in   range(100)]   for   b   in   range(100)] 
