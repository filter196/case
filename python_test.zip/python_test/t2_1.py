#!/usr/bin/env python
class clas1():
  def f(self):
    print 'in clas1'
    print l
    def f1():
	print l

def t():
  ta = 't1'
  print a
  print l
  l.extend(['c'])
  def t1():
    pass
  t1()

if 1==2:
  a = 1;
else:
  print 'here !!!'

if 1==1:
  b = 1
  c = 1

l = ['hello','b']
#a = 2
t()
print a
print b
print l

m = clas1()
m.f()
