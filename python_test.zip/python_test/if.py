if a+1 >= 1 and a == 3 and a == 5 and 1 and 2:
	a and b
	a = a + 1
	b = a
elif a == 0 or a < b+1 or a == 1:
	a = 100
elif a()+1:
	pass
elif not a:
	pass
elif cc:
	pass
elif a > b > c < 1:
	pass
elif (a>b)>(c==d):
#	break
	pass
else:
	print "error!"
