result = f2(1,2)

def f2(x,n):
	f2(1,2)

def t():
   print "hello world"

result = f2(1,2)
