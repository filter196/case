raise RuntimeError("generator ignored GeneratorExit"),1.0+2.0
