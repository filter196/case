
x = 1
if x < 0:
	c = x
elif x == 0:
	c = d
elif x == 1:
	c = f
else:
	c = h

print g	
