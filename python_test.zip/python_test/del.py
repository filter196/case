
a = 1
del a
