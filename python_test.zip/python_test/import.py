import b as y
import a.b.c
from a import aa,bb as yy,cc
from c import *

hmm = __import__('os')

class class1:
	def main():
		a=1
		b=1+a*2-a/2
		s = pip_r.a.b.read(5)
		print 'a'
		print(a)
		main(a)
		main
		(b)
		12(a)
