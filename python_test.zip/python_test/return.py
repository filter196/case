return 1 + a.b + c[d], 1
return
return 1 + a
return a
return 1
