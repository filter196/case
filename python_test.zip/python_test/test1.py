
os.system(测试中文变量)
